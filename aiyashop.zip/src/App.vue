<script setup>
import { onMounted, ref } from "vue";
import { useUserStore } from "./stores/user";
import Toast from "./components/Toast.vue";
import GlobalBanner from "./components/GlobalBanner.vue";

const userStore = useUserStore();
const isLoading = ref(true);

onMounted(async () => {
    // 1. Inisialisasi Auth
    userStore.initAuth();

    // 2. OPTIMASI: Hapus delay 3 detik.
    // Cukup 800ms agar transisi halus, tapi terasa instan.
    setTimeout(() => {
        isLoading.value = false;
    }, 800);
});
</script>

<template>
    <div
        class="min-h-screen bg-[#F2F2F7] dark:bg-[#000000] text-slate-900 dark:text-white transition-colors duration-300 font-sans"
    >
        <!-- Global Components -->
        <GlobalBanner />
        <Toast />

        <!-- LOADING SCREEN OPTIMIZED -->
        <transition name="fade">
            <div
                v-if="isLoading"
                class="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#F2F2F7] dark:bg-[#000000]"
            >
                <!-- VIDEO ASSETS -->
                <div class="relative w-32 h-32 mb-4">
                    <video
                        autoplay
                        loop
                        muted
                        playsinline
                        class="w-full h-full object-contain pointer-events-none drop-shadow-2xl"
                    >
                        <source src="@/assets/skykid.webm" type="video/webm" />
                        <source src="@/assets/skykid.mp4" type="video/mp4" />
                        <!-- Fallback -->
                        <img
                            src="@/assets/skykid.gif"
                            class="w-full h-full object-contain"
                        />
                    </video>
                </div>

                <h1
                    class="text-xl font-black tracking-widest text-slate-300 animate-pulse"
                >
                    AIYASHOP
                </h1>
            </div>
        </transition>

        <!-- MAIN CONTENT -->
        <div v-show="!isLoading" class="animate-in fade-in duration-700">
            <router-view />
        </div>
    </div>
</template>

<style>
/* Global Transition */
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.4s ease;
}
.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}

/* Scrollbar Cozy */
::-webkit-scrollbar {
    width: 6px;
}
::-webkit-scrollbar-track {
    background: transparent;
}
::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
}
.dark ::-webkit-scrollbar-thumb {
    background: #334155;
}
</style>
