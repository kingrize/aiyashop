<script setup>
import { ref, computed, watch, reactive } from "vue";
import { useCartStore } from "../stores/cart";
import { usePromoStore } from "../stores/promo";
import { useUserStore } from "../stores/user";
import ManualPaymentModal from "./ManualPaymentModal.vue";
import {
    ShoppingBag,
    X,
    Trash2,
    Wind,
    MessageCircle,
    Star,
    Heart,
    Flame,
    Cloud,
    Sparkles,
    Tag,
    Loader2,
    XCircle,
    Moon,
    Info,
    QrCode,
    UserCheck,
    Wallet,
    CheckCircle2,
    AlertCircle,
    Check,
    Zap,
    ArrowRight,
    ShieldCheck,
    User,
    UserPlus,
} from "lucide-vue-next";
import {
    doc,
    updateDoc,
    increment,
    collection,
    addDoc,
    serverTimestamp,
} from "firebase/firestore";
import { db } from "../firebase";

const store = useCartStore();
const promoStore = usePromoStore();
const userStore = useUserStore();

const promoInput = ref("");
const promoMessage = ref("");
const selectedPayment = ref("qris");

const showConfirmModal = ref(false);
const showSuccessModal = ref(false);
const isProcessingPayment = ref(false);
const countdown = ref(3);

// --- STATE MANUAL PAYMENT ---
const showManualPayment = ref(false);
const manualPaymentData = ref({ total: 0, id: "" });

const authForm = reactive({ username: "", password: "" });
const isAuthLoading = ref(false);

watch(
    () => userStore.user,
    (newUser) => {
        if (newUser && userStore.memberData?.saldo >= store.totalPrice) {
            selectedPayment.value = "member";
        }
    },
);

const finalTotalComputed = computed(() =>
    promoStore.activeCode && isPromoEligible.value
        ? promoStore.calculateTotal(store.totalPrice)
        : store.totalPrice,
);

const memberBalanceAfter = computed(() => {
    return (userStore.memberData?.saldo || 0) - finalTotalComputed.value;
});

const getIcon = (type) => {
    const map = {
        wind: Wind,
        star: Star,
        heart: Heart,
        flame: Flame,
        cloud: Cloud,
        sparkles: Sparkles,
        moon: Moon,
        zap: Zap,
    };
    return map[type?.toLowerCase()] || Sparkles;
};

const getItemTheme = (item) => {
    if (item.category === "heart")
        return "bg-rose-100 text-rose-500 dark:bg-rose-900/30 dark:text-rose-400";
    if (item.category === "candlerun")
        return "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400";
    if (item.category === "special")
        return "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400";
    return "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400";
};

const formatRupiah = (num) =>
    new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
        minimumFractionDigits: 0,
    }).format(num);

const MIN_ORDER_FOR_PROMO = 10000;
const amountNeededForPromo = computed(() =>
    Math.max(0, MIN_ORDER_FOR_PROMO - store.totalPrice),
);
const isPromoEligible = computed(() => store.totalPrice >= MIN_ORDER_FOR_PROMO);

const handleApplyPromo = async () => {
    if (!promoInput.value) return;
    const result = await promoStore.applyPromo(promoInput.value);
    promoMessage.value = result.message;
    setTimeout(() => (promoMessage.value = ""), 3000);
};

const handleAuthSubmit = async () => {
    isAuthLoading.value = true;
    try {
        if (!authForm.username || !authForm.password)
            throw new Error("Username & Password wajib!");
        await userStore.login(authForm.username, authForm.password);
    } catch (e) {
        alert(e.message || "Gagal login");
    } finally {
        isAuthLoading.value = false;
    }
};

const handleCheckoutClick = () => {
    if (store.items.length === 0) return;

    if (selectedPayment.value === "member") {
        if (!userStore.user) {
            alert("Silakan login dulu ya kak! 😊");
            return;
        }
        if (userStore.memberData?.saldo < finalTotalComputed.value) {
            alert("Yah, saldo member kakak kurang nih 🥺 Topup dulu yuk!");
            return;
        }
        showConfirmModal.value = true;
    } else {
        // --- LOGIC BARU: MANUAL PAYMENT (QRIS) ---
        const uniqueCode = Math.floor(Math.random() * 500) + 1;
        const totalWithCode = finalTotalComputed.value + uniqueCode;
        const orderId = `ORD-${Date.now().toString().slice(-4)}-${Math.floor(Math.random() * 100)}`;

        manualPaymentData.value = {
            total: totalWithCode,
            id: orderId,
        };
        showManualPayment.value = true;
    }
};

const confirmMemberPayment = async () => {
    isProcessingPayment.value = true;
    const total = finalTotalComputed.value;

    try {
        const userRef = doc(db, "users", userStore.user.uid);
        await updateDoc(userRef, {
            saldo: increment(-total),
            totalTopUp: increment(0),
        });

        await userStore.fetchMemberData();

        try {
            const summaryItems = store.items
                .map((i) => `${i.name} (${i.qty}x)`)
                .join(", ");
            await addDoc(
                collection(db, "users", userStore.user.uid, "transactions"),
                {
                    type: "expense",
                    title: "Pembelian Joki",
                    desc: summaryItems,
                    amount: total,
                    createdAt: serverTimestamp(),
                    status: "success",
                },
            );
            if (userStore.fetchTransactions)
                await userStore.fetchTransactions();
        } catch (historyError) {
            console.warn("Gagal mencatat history:", historyError);
        }

        showConfirmModal.value = false;
        showSuccessModal.value = true;

        store.clearCart();
        promoStore.resetPromo();

        countdown.value = 3;
        const timer = setInterval(() => {
            countdown.value--;
            if (countdown.value <= 0) {
                clearInterval(timer);
                processCheckout("LUNAS (Saldo Member)");
                setTimeout(() => {
                    showSuccessModal.value = false;
                    store.toggleCart();
                }, 1000);
            }
        }, 1000);
    } catch (error) {
        console.error("Error transaksi:", error);
        alert("Gagal memproses pembayaran. Saldo aman. Coba lagi ya!");
    } finally {
        isProcessingPayment.value = false;
    }
};

const processCheckout = (statusBayar) => {
    let message = "Halo Admin Aiya! ✨ Saya mau order dong:%0A%0A";

    if (store.items.length === 0 && statusBayar.includes("LUNAS")) {
        message += "✅ *Pembayaran LUNAS via Saldo Member*%0A";
        message +=
            "Mohon segera diproses ya min! Detail pesanan sudah masuk di sistem.";
    }

    if (userStore.user) {
        message += `%0A👤 User: ${userStore.user.displayName}`;
        message += `%0A📧 Email: ${userStore.user.email}`;
    }

    message += `%0AMetode Bayar: ${selectedPayment.value === "member" ? "💎 Saldo Member" : "QRIS / E-Wallet"}`;
    message += `%0AStatus: *${statusBayar}*`;

    window.open(`https://wa.me/6285942963323?text=${message}`, "_blank");
};
</script>

<template>
    <div class="cart-drawer">
        <transition name="fade">
            <div
                v-if="store.isOpen"
                class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] transition-opacity"
                @click="store.toggleCart()"
            ></div>
        </transition>

        <div
            class="fixed top-0 right-0 h-full w-full md:w-[420px] bg-[#FDFBF7] dark:bg-charcoal z-[70] shadow-2xl transform transition-transform duration-500 cubic-bezier(0.32, 0.72, 0, 1)"
            :class="store.isOpen ? 'translate-x-0' : 'translate-x-full'"
        >
            <div class="h-full flex flex-col relative overflow-hidden">
                <div
                    class="absolute top-0 right-0 w-64 h-64 bg-sky-100 dark:bg-slate-800/50 rounded-full blur-3xl -z-10 opacity-60 pointer-events-none"
                ></div>

                <div
                    class="p-6 flex justify-between items-center bg-white/50 dark:bg-charcoal/80 backdrop-blur-md border-b border-sky-100/50 dark:border-slate-800"
                >
                    <h2
                        class="text-xl font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2"
                    >
                        <ShoppingBag class="text-sky-500" /> Keranjang
                    </h2>
                    <button
                        @click="store.toggleCart()"
                        class="p-2 hover:bg-rose-50 dark:hover:bg-slate-800 text-slate-400 dark:text-slate-500 hover:text-rose-500 dark:hover:text-rose-400 rounded-full transition"
                    >
                        <X :size="24" />
                    </button>
                </div>

                <div
                    class="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar"
                >
                    <div
                        v-if="store.items.length === 0"
                        class="text-center py-20 flex flex-col items-center"
                    >
                        <div
                            class="bg-sky-50 dark:bg-slate-800 p-6 rounded-full mb-4 animate-float-slow"
                        >
                            <Wind
                                class="text-sky-300 dark:text-sky-500"
                                :size="48"
                            />
                        </div>
                        <p
                            class="text-slate-500 dark:text-slate-400 font-bold mb-2"
                        >
                            Keranjang masih kosong...
                        </p>
                        <button
                            @click="store.toggleCart()"
                            class="text-sky-500 dark:text-sky-400 font-bold hover:underline"
                        >
                            Lihat Menu
                        </button>
                    </div>

                    <div
                        v-else
                        v-for="item in store.items"
                        :key="item.id"
                        class="bg-white dark:bg-graphite p-4 rounded-3xl border border-sky-50 dark:border-slate-700 shadow-sm flex gap-4 items-start group hover:shadow-md transition relative"
                    >
                        <div
                            :class="`w-12 h-12 rounded-2xl ${getItemTheme(item)} flex items-center justify-center shrink-0 mt-1 shadow-sm`"
                        >
                            <component
                                :is="getIcon(item.iconType)"
                                :size="20"
                                stroke-width="2.5"
                            />
                        </div>
                        <div class="flex-1 min-w-0 pr-8">
                            <h4
                                class="font-bold text-slate-700 dark:text-slate-200 text-sm truncate"
                            >
                                {{ item.name }}
                            </h4>
                            <p
                                class="text-[10px] text-slate-400 dark:text-slate-500 mb-2 line-clamp-2 leading-relaxed"
                            >
                                {{ item.desc }}
                            </p>
                            <div class="flex items-center justify-between">
                                <p
                                    class="text-sky-500 dark:text-sky-400 font-bold text-sm"
                                >
                                    {{ formatRupiah(item.price * item.qty) }}
                                </p>
                                <div
                                    class="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg p-1 border border-slate-100 dark:border-slate-700"
                                >
                                    <button
                                        @click="store.updateQty(item.id, -1)"
                                        class="w-5 h-5 flex items-center justify-center text-slate-400 hover:bg-white dark:hover:bg-slate-600 hover:text-rose-500 rounded transition"
                                    >
                                        -
                                    </button>
                                    <span
                                        class="text-xs font-bold w-4 text-center text-slate-600 dark:text-slate-300"
                                        >{{ item.qty }}</span
                                    >
                                    <button
                                        @click="store.updateQty(item.id, 1)"
                                        class="w-5 h-5 flex items-center justify-center text-slate-400 hover:bg-white dark:hover:bg-slate-600 hover:text-emerald-500 rounded transition"
                                    >
                                        +
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button
                            @click="store.removeItem(item.id)"
                            class="absolute top-3 right-3 p-1.5 text-slate-300 dark:text-slate-600 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-slate-700 dark:hover:text-rose-400 rounded-lg transition"
                            title="Hapus Item"
                        >
                            <Trash2 :size="16" />
                        </button>
                    </div>
                </div>

                <div
                    class="bg-white dark:bg-graphite border-t border-dashed border-sky-100 dark:border-slate-700 relative z-10 shadow-[0_-10px_40px_rgba(0,0,0,0.05)]"
                >
                    <div class="px-6 pt-4 pb-2">
                        <div class="flex gap-2">
                            <div class="relative flex-1 group">
                                <div
                                    class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"
                                >
                                    <Tag
                                        :size="16"
                                        class="text-slate-400 group-focus-within:text-sky-500 transition"
                                    />
                                </div>
                                <input
                                    v-model="promoInput"
                                    type="text"
                                    placeholder="Kode Promo"
                                    class="pl-9 pr-8 w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-xl py-2.5 text-sm focus:outline-none focus:border-sky-300 focus:ring-4 focus:ring-sky-50 dark:focus:ring-slate-700 transition uppercase font-bold text-slate-600 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500"
                                    @keyup.enter="handleApplyPromo"
                                    :disabled="!!promoStore.activeCode"
                                />
                                <button
                                    v-if="promoStore.activeCode"
                                    @click="
                                        promoStore.resetPromo();
                                        promoInput = '';
                                    "
                                    class="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-rose-500 cursor-pointer transition"
                                >
                                    <XCircle :size="16" />
                                </button>
                            </div>
                            <button
                                @click="handleApplyPromo"
                                :disabled="
                                    promoStore.isLoading ||
                                    !promoInput ||
                                    !!promoStore.activeCode
                                "
                                class="bg-slate-800 dark:bg-slate-700 text-white px-5 py-2 rounded-xl text-xs font-bold hover:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-lg shadow-slate-200 dark:shadow-none flex items-center justify-center min-w-[70px]"
                            >
                                <Loader2
                                    v-if="promoStore.isLoading"
                                    :size="16"
                                    class="animate-spin"
                                />
                                <span v-else>{{
                                    promoStore.activeCode ? "Aktif" : "Pakai"
                                }}</span>
                            </button>
                        </div>
                        <p
                            v-if="promoMessage"
                            class="text-[10px] mt-2 font-bold ml-1 flex items-center gap-1"
                            :class="
                                promoStore.error
                                    ? 'text-rose-500'
                                    : 'text-emerald-500'
                            "
                        >
                            <Sparkles v-if="!promoStore.error" :size="12" />
                            {{ promoMessage }}
                        </p>
                    </div>

                    <div class="px-6 py-2">
                        <p
                            class="text-xs font-bold text-slate-500 dark:text-slate-400 mb-2"
                        >
                            Pilih Pembayaran
                        </p>
                        <div
                            class="flex gap-2 overflow-x-auto pb-2 custom-scrollbar"
                        >
                            <button
                                @click="selectedPayment = 'qris'"
                                class="flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-medium transition whitespace-nowrap"
                                :class="
                                    selectedPayment === 'qris'
                                        ? 'bg-sky-50 dark:bg-sky-900/30 border-sky-300 dark:border-sky-700 text-sky-600 dark:text-sky-300 shadow-sm'
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                                "
                            >
                                <QrCode :size="14" /> QRIS / E-Wallet
                            </button>
                            <button
                                @click="selectedPayment = 'member'"
                                class="flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-medium transition whitespace-nowrap"
                                :class="
                                    selectedPayment === 'member'
                                        ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-300 dark:border-indigo-700 text-indigo-600 dark:text-indigo-300 shadow-sm'
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                                "
                            >
                                <UserCheck :size="14" /> Member
                            </button>
                        </div>

                        <transition name="fade">
                            <div
                                v-if="selectedPayment === 'member'"
                                class="mt-3 bg-indigo-50 dark:bg-indigo-950/40 p-3 rounded-xl border border-indigo-100 dark:border-indigo-900 relative overflow-hidden"
                            >
                                <div v-if="userStore.user">
                                    <div
                                        class="flex justify-between items-center mb-1"
                                    >
                                        <span
                                            class="text-xs font-bold text-indigo-700 dark:text-indigo-300"
                                            >Saldo Kamu:</span
                                        ><span
                                            class="text-sm font-extrabold text-indigo-600 dark:text-indigo-400"
                                            >{{
                                                formatRupiah(
                                                    userStore.memberData?.saldo,
                                                )
                                            }}</span
                                        >
                                    </div>
                                    <div
                                        v-if="
                                            userStore.memberData?.saldo <
                                            promoStore.calculateTotal(
                                                store.totalPrice,
                                            )
                                        "
                                        class="text-[10px] text-rose-500 font-bold flex items-center gap-1 mt-1"
                                    >
                                        <XCircle :size="12" /> Saldo kurang,
                                        topup ke admin ya!
                                    </div>
                                    <div
                                        v-else
                                        class="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 mt-1"
                                    >
                                        <CheckCircle2 :size="12" /> Saldo cukup,
                                        siap potong!
                                    </div>
                                </div>
                                <div v-else>
                                    <p
                                        class="text-[10px] text-indigo-500 dark:text-indigo-300 mb-2 font-bold text-center"
                                    >
                                        Login Member Only 🔐
                                    </p>
                                    <div class="space-y-2">
                                        <div class="relative">
                                            <span
                                                class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                                                ><User :size="14"
                                            /></span>
                                            <input
                                                v-model="authForm.username"
                                                type="text"
                                                placeholder="Username"
                                                class="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-950 text-slate-700 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-indigo-400"
                                            />
                                        </div>
                                        <input
                                            v-model="authForm.password"
                                            type="password"
                                            placeholder="Password"
                                            class="w-full px-3 py-1.5 text-xs rounded-lg border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-950 text-slate-700 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-indigo-400"
                                        />
                                    </div>
                                    <p
                                        v-if="userStore.authError"
                                        class="text-[9px] text-rose-500 mt-2 font-bold flex items-center gap-1"
                                    >
                                        <AlertCircle :size="10" />
                                        {{ userStore.authError }}
                                    </p>

                                    <div class="mt-3 space-y-2">
                                        <button
                                            @click="handleAuthSubmit"
                                            :disabled="isAuthLoading"
                                            class="w-full bg-indigo-600 text-white py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-700 disabled:opacity-50 flex justify-center items-center gap-1"
                                        >
                                            <Loader2
                                                v-if="isAuthLoading"
                                                :size="12"
                                                class="animate-spin"
                                            />
                                            Masuk
                                        </button>
                                        <a
                                            href="https://wa.me/6285942963323?text=Halo%20Admin%20Aiya!%20Saya%20mau%20daftar%20member%20baru%20dong%20✨"
                                            target="_blank"
                                            class="block text-center text-[10px] text-indigo-500 dark:text-indigo-400 font-bold hover:underline flex items-center justify-center gap-1"
                                            >Belum punya akun? Daftar via WA
                                            <UserPlus :size="12"
                                        /></a>
                                    </div>
                                </div>
                            </div>
                        </transition>
                    </div>

                    <div class="p-6 pt-2 space-y-3">
                        <div
                            class="flex justify-between items-center text-xs text-slate-400 dark:text-slate-500"
                        >
                            <span>Subtotal</span
                            ><span>{{ formatRupiah(store.totalPrice) }}</span>
                        </div>
                        <div
                            v-if="promoStore.activeCode && isPromoEligible"
                            class="flex justify-between items-center text-xs font-bold text-emerald-500 bg-emerald-50 dark:bg-emerald-900/30 p-2 rounded-lg border border-emerald-100 dark:border-emerald-800 animate-in slide-in-from-left-2"
                        >
                            <span class="flex items-center gap-1"
                                ><Tag :size="12" /> Hemat ({{
                                    promoStore.activeCode
                                }})</span
                            ><span
                                >-
                                {{
                                    formatRupiah(
                                        promoStore.savings(store.totalPrice),
                                    )
                                }}</span
                            >
                        </div>
                        <div
                            class="flex justify-between items-end pt-2 border-t border-slate-100 dark:border-slate-700"
                        >
                            <span
                                class="text-sm font-bold text-slate-600 dark:text-slate-300"
                                >Total Bayar</span
                            ><span
                                class="text-2xl font-extrabold text-sky-500 dark:text-sky-400"
                                >{{
                                    formatRupiah(
                                        promoStore.activeCode && isPromoEligible
                                            ? promoStore.calculateTotal(
                                                  store.totalPrice,
                                              )
                                            : store.totalPrice,
                                    )
                                }}</span
                            >
                        </div>
                        <button
                            @click="handleCheckoutClick"
                            :disabled="
                                store.items.length === 0 || isProcessingPayment
                            "
                            class="w-full btn-bouncy text-white font-bold py-4 rounded-2xl shadow-lg flex justify-center items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-4 hover:brightness-105"
                            :class="
                                selectedPayment === 'member'
                                    ? 'bg-gradient-to-r from-indigo-500 to-purple-500 shadow-indigo-100 dark:shadow-none'
                                    : 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-emerald-100 dark:shadow-none'
                            "
                        >
                            <Loader2
                                v-if="isProcessingPayment"
                                :size="20"
                                class="animate-spin"
                            />
                            <span
                                v-else-if="selectedPayment === 'member'"
                                class="flex items-center gap-2"
                                ><Wallet :size="20" /> Gunakan Saldo</span
                            >
                            <span v-else class="flex items-center gap-2"
                                ><MessageCircle :size="20" /> Checkout
                                Sekarang</span
                            >
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <transition name="fade">
            <div
                v-if="showConfirmModal"
                class="fixed inset-0 z-[80] flex items-center justify-center p-4"
            >
                <div
                    class="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
                    @click="showConfirmModal = false"
                ></div>
                <div
                    class="bg-white dark:bg-charcoal w-full max-w-sm rounded-[2.5rem] shadow-2xl relative z-10 animate-in fade-in zoom-in-95 duration-200 overflow-hidden border border-white/20"
                >
                    <div
                        class="bg-white dark:bg-slate-900 p-6 pb-4 text-center border-b border-slate-100 dark:border-slate-800"
                    >
                        <div
                            class="w-16 h-16 bg-indigo-50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto mb-3"
                        >
                            <ShieldCheck
                                :size="32"
                                class="text-indigo-600 dark:text-indigo-400"
                            />
                        </div>
                        <h3
                            class="text-xl font-bold text-slate-800 dark:text-slate-100"
                        >
                            Konfirmasi Pembayaran
                        </h3>
                        <p
                            class="text-slate-500 dark:text-slate-400 text-xs mt-1"
                        >
                            Pastikan saldo kamu cukup ya!
                        </p>
                    </div>
                    <div class="p-6 bg-slate-50 dark:bg-slate-800/50">
                        <div class="space-y-4">
                            <div
                                class="flex justify-between items-center text-sm"
                            >
                                <span class="text-slate-500 dark:text-slate-400"
                                    >Saldo Awal</span
                                ><span
                                    class="font-bold text-slate-700 dark:text-slate-200"
                                    >{{
                                        formatRupiah(
                                            userStore.memberData?.saldo,
                                        )
                                    }}</span
                                >
                            </div>
                            <div
                                class="flex justify-between items-center text-sm"
                            >
                                <span class="text-slate-500 dark:text-slate-400"
                                    >Total Belanja</span
                                ><span class="font-bold text-rose-500"
                                    >-
                                    {{ formatRupiah(finalTotalComputed) }}</span
                                >
                            </div>
                            <div
                                class="h-px bg-slate-200 dark:bg-slate-700 border-dashed border-t"
                            ></div>
                            <div
                                class="flex justify-between items-center bg-white dark:bg-slate-800 p-3 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm"
                            >
                                <div class="flex items-center gap-2">
                                    <div
                                        class="p-1.5 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg text-emerald-600"
                                    >
                                        <Wallet :size="16" />
                                    </div>
                                    <span
                                        class="text-xs font-bold text-slate-600 dark:text-slate-300"
                                        >Sisa Saldo</span
                                    >
                                </div>
                                <span
                                    class="font-black text-emerald-600 dark:text-emerald-400"
                                    >{{
                                        formatRupiah(memberBalanceAfter)
                                    }}</span
                                >
                            </div>
                        </div>
                        <div class="flex gap-3 mt-6">
                            <button
                                @click="showConfirmModal = false"
                                class="flex-1 py-3.5 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 transition"
                            >
                                Batal
                            </button>
                            <button
                                @click="confirmMemberPayment"
                                class="flex-[2] py-3.5 rounded-xl bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-200 dark:shadow-none hover:bg-indigo-700 transition btn-bouncy flex items-center justify-center gap-2"
                            >
                                Bayar <ArrowRight :size="18" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>

        <transition name="fade">
            <div
                v-if="showSuccessModal"
                class="fixed inset-0 z-[90] flex items-center justify-center p-4"
            >
                <div
                    class="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
                ></div>
                <div
                    class="bg-white dark:bg-charcoal w-full max-w-sm rounded-[2.5rem] shadow-2xl relative z-10 animate-in fade-in zoom-in-95 duration-300 p-8 text-center border-4 border-emerald-50 dark:border-emerald-900"
                >
                    <div
                        class="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce"
                    >
                        <Check
                            :size="40"
                            class="text-emerald-500"
                            stroke-width="3"
                        />
                    </div>
                    <h3
                        class="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mb-2"
                    >
                        Pembayaran Sukses!
                    </h3>
                    <p class="text-slate-500 dark:text-slate-400 text-sm mb-6">
                        Yeay! Saldo berhasil dipotong. <br />Mengalihkan ke
                        WhatsApp dalam
                        <span
                            class="font-bold text-emerald-600 dark:text-emerald-400"
                            >{{ countdown }}</span
                        >...
                    </p>
                    <button
                        class="w-full py-3 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 font-bold hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition"
                        disabled
                    >
                        Mohon tunggu sebentar... ⏳
                    </button>
                </div>
            </div>
        </transition>

        <Teleport to="body">
            <ManualPaymentModal
                :is-open="showManualPayment"
                :total-price="manualPaymentData.total"
                :order-id="manualPaymentData.id"
                @close="showManualPayment = false"
            />
        </Teleport>
    </div>
</template>

<style scoped>
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
.custom-scrollbar::-webkit-scrollbar {
    width: 4px;
    height: 4px;
}
.custom-scrollbar::-webkit-scrollbar-track {
    background: transparent;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
    background-color: #e2e8f0;
    border-radius: 20px;
}
:global(.dark) .custom-scrollbar::-webkit-scrollbar-thumb {
    background-color: rgba(255, 255, 255, 0.1);
}
:global(.dark) .cart-drawer button:focus {
    box-shadow: none !important;
    outline: 2px solid rgba(255, 255, 255, 0.06);
    outline-offset: 2px;
}
</style>
