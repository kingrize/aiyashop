// src/stores/delivery.js
// Unified store (admin + public) + auto-sync to `delivery_public`

import { defineStore } from "pinia";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../firebase";

const PRIVATE_COL = "delivery_orders";
const PUBLIC_COL = "delivery_public";

function toUpperCode(v) {
  return String(v || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "");
}

function safeNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function sumLogs(logs) {
  if (!Array.isArray(logs)) return 0;
  return logs.reduce((acc, it) => acc + safeNumber(it?.amount), 0);
}

function buildPublicDocFromPrivate(order) {
  // order: { trackingCode, customerName, username, usernameAlias, productName, totalTarget, perDay, status, logs, createdAt, updatedAt }
  const trackingCode = toUpperCode(order?.trackingCode);
  const customerName = String(order?.customerName || "").trim();

  // ✅ Sesuai request kamu:
  // - Nama customer: tampil apa adanya (admin input)
  // - Username: yang di-alias
  const usernameAlias = String(order?.usernameAlias || "").trim();

  const productName = String(order?.productName || order?.title || "Pesanan").trim();
  const totalTarget = safeNumber(order?.totalTarget ?? order?.total ?? order?.totalAmount);
  const perDay = safeNumber(order?.perDay);
  const deliveredTotal = safeNumber(order?.deliveredTotal ?? order?.delivered ?? order?.sent ?? sumLogs(order?.logs));

  // NOTE: TrackAll/TrackOrder yang "cozy" lama baca field-field ini:
  // - customerAlias / customerMasked
  // - deliveredTotal / delivered
  // - totalTarget / total
  // - title / productName
  // Jadi kita isi semuanya biar kompatibel.

  return {
    trackingCode,

    // Display
    title: productName, // bisa kamu ganti jadi `${productName}`
    productName,

    // Nama customer tampil normal
    customerName: customerName || "Customer",

    // Kompat lama
    customerAlias: customerName || "Customer",
    customerMasked: customerName || "Customer",

    // Username (disamarkan)
    usernameAlias: usernameAlias || "-",

    // Progress
    totalTarget,
    total: totalTarget,
    deliveredTotal,
    delivered: deliveredTotal,
    perDay,

    status: String(order?.status || "process"),

    // Optional (dipakai UI detail jika ada)
    logs: Array.isArray(order?.logs) ? order.logs : [],

    // Timestamps
    createdAt: order?.createdAt ?? null,
    updatedAt: order?.updatedAt ?? null,
  };
}

export const useDeliveryStore = defineStore("delivery", {
  state: () => ({
    // admin
    items: [],
    isLoading: false,
    error: "",

    // public
    publicOrder: null,
    publicList: [],
  }),

  actions: {
    // ------------------------
    // PUBLIC
    // ------------------------
    clearPublic() {
      this.publicOrder = null;
    },

    async fetchPublicByCode(code) {
      const c = toUpperCode(code);
      if (!c) throw new Error("Missing code");

      const ref = doc(db, PUBLIC_COL, c);
      const snap = await getDoc(ref);

      if (!snap.exists()) {
        this.publicOrder = null;
        throw new Error("Not found");
      }

      this.publicOrder = { id: snap.id, ...snap.data() };
      return this.publicOrder;
    },

    async fetchPublicList({ max = 200 } = {}) {
      const qy = query(
        collection(db, PUBLIC_COL),
        orderBy("updatedAt", "desc"),
        limit(max),
      );
      const snaps = await getDocs(qy);
      this.publicList = snaps.docs.map((d) => ({ id: d.id, ...d.data() }));
      return this.publicList;
    },

    // ------------------------
    // ADMIN
    // ------------------------
    async fetchAll({ max = 500 } = {}) {
      this.isLoading = true;
      this.error = "";
      try {
        const qy = query(
          collection(db, PRIVATE_COL),
          orderBy("updatedAt", "desc"),
          limit(max),
        );
        const snaps = await getDocs(qy);
        this.items = snaps.docs.map((d) => ({ id: d.id, ...d.data() }));
        return this.items;
      } catch (e) {
        console.error(e);
        this.error = e?.message || "Gagal memuat delivery orders";
        throw e;
      } finally {
        this.isLoading = false;
      }
    },

    // Kalau kamu punya data lama yang belum kebentuk di `delivery_public`,
    // jalankan ini sekali dari /admin (misal lewat tombol "Resync").
    async resyncAllToPublic({ max = 500 } = {}) {
      const items = await this.fetchAll({ max });
      for (const it of items) {
        try {
          await this._syncToPublic(it, { merge: true });
        } catch (e) {
          console.warn("Resync gagal untuk", it?.trackingCode, e);
        }
      }
      return true;
    },

    // Backward-compatible alias (biar DeliveriesPanel lama tetap jalan)
    async fetchPrivateOrders(opts) {
      return this.fetchAll(opts);
    },

    async createOrder(payload) {
      // payload minimal yg kamu input di /admin:
      // { trackingCode, customerName, username, usernameAlias, productName, totalTarget, perDay, status }
      const trackingCode = toUpperCode(payload?.trackingCode);
      if (!trackingCode) throw new Error("Tracking code wajib");

      const customerName = String(payload?.customerName || "Customer").trim();
      const username = String(payload?.username || "").trim();
      const usernameAlias = String(payload?.usernameAlias || "").trim();
      const productName = String(payload?.productName || "Pesanan").trim();

      const totalTarget = safeNumber(payload?.totalTarget ?? payload?.total);
      const perDay = safeNumber(payload?.perDay);
      const status = String(payload?.status || "process");

      const docData = {
        trackingCode,
        customerName,
        username,
        usernameAlias,
        productName,
        totalTarget,
        perDay,
        status,
        logs: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      const ref = await addDoc(collection(db, PRIVATE_COL), docData);

      // Important: sync public doc by trackingCode
      await this._syncToPublic({ ...docData, id: ref.id, deliveredTotal: 0, updatedAt: new Date() }, { merge: false });

      return ref.id;
    },

    // Backward-compatible alias
    async createDelivery(payload) {
      return this.createOrder(payload);
    },

    async addProgress({ id, amount, note, date }) {
      // update private doc logs + sync
      const ref = doc(db, PRIVATE_COL, id);
      const snap = await getDoc(ref);
      if (!snap.exists()) throw new Error("Order not found");

      const data = snap.data();
      const logs = Array.isArray(data.logs) ? [...data.logs] : [];

      logs.unshift({
        amount: safeNumber(amount),
        note: String(note || "").trim(),
        date: date ? new Date(date) : new Date(),
      });

      const deliveredTotal = sumLogs(logs);

      await updateDoc(ref, {
        logs,
        deliveredTotal,
        updatedAt: serverTimestamp(),
      });

      await this._syncToPublic({ ...data, trackingCode: data.trackingCode, logs, deliveredTotal, updatedAt: new Date() }, { merge: true });
    },

    // Backward-compatible alias
    async upsertLog(payload) {
      return this.addProgress(payload);
    },

    async setStatus({ id, status }) {
      const ref = doc(db, PRIVATE_COL, id);
      const snap = await getDoc(ref);
      if (!snap.exists()) throw new Error("Order not found");

      const data = snap.data();
      const s = String(status || "process");

      await updateDoc(ref, { status: s, updatedAt: serverTimestamp() });
      await this._syncToPublic({ ...data, status: s, updatedAt: new Date() }, { merge: true });
    },

    // Backward-compatible alias
    async setStatusStatus(payload) {
      return this.setStatus(payload);
    },

    async removeOrder({ id }) {
      const ref = doc(db, PRIVATE_COL, id);
      const snap = await getDoc(ref);
      const data = snap.exists() ? snap.data() : null;

      await deleteDoc(ref);

      // optional: juga hapus public kalau trackingCode ada
      const code = toUpperCode(data?.trackingCode);
      if (code) {
        try {
          await deleteDoc(doc(db, PUBLIC_COL, code));
        } catch (e) {
          console.warn("Gagal hapus public doc", e);
        }
      }
    },

    // ------------------------
    // INTERNAL
    // ------------------------
    async _syncToPublic(orderLike, { merge = true } = {}) {
      const trackingCode = toUpperCode(orderLike?.trackingCode);
      if (!trackingCode) return;

      // Normalize + compute delivered
      const logs = Array.isArray(orderLike?.logs) ? orderLike.logs : [];
      const deliveredTotal = safeNumber(orderLike?.deliveredTotal ?? sumLogs(logs));

      const normalized = {
        ...orderLike,
        trackingCode,
        logs,
        deliveredTotal,
        updatedAt: serverTimestamp(),
      };

      const publicDoc = buildPublicDocFromPrivate(normalized);

      const payload = {
        ...publicDoc,
        updatedAt: serverTimestamp(),
      };

      // createdAt hanya set saat doc baru dibuat
      if (!merge) payload.createdAt = serverTimestamp();

      await setDoc(doc(db, PUBLIC_COL, trackingCode), payload, { merge });
    },
  },
});
