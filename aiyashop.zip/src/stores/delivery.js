// src/stores/delivery.js
import { defineStore } from "pinia";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  orderBy,
  limit,
} from "firebase/firestore";
import { db } from "../firebase";

/**
 * Koleksi publik untuk tracking:
 * - delivery_public/{TRACKING_CODE}
 * Isinya data yang aman untuk ditampilkan publik.
 */
const PUBLIC_COL = "delivery_public";

export const useDeliveryStore = defineStore("delivery", {
  state: () => ({
    publicOrder: null,
    publicList: [],
  }),

  actions: {
    clearPublic() {
      this.publicOrder = null;
    },

    async fetchPublicByCode(code) {
      const c = String(code || "").trim().toUpperCase();
      if (!c) throw new Error("Missing code");

      const ref = doc(db, PUBLIC_COL, c);
      const snap = await getDoc(ref);

      if (!snap.exists()) {
        this.publicOrder = null;
        throw new Error("Not found");
      }

      this.publicOrder = { id: snap.id, ...snap.data() };
    },

    async fetchPublicList() {
      // Ambil terbaru (bisa kamu ubah sortnya)
      const qy = query(
        collection(db, PUBLIC_COL),
        orderBy("updatedAt", "desc"),
        limit(200),
      );

      const snaps = await getDocs(qy);
      this.publicList = snaps.docs.map((d) => ({ id: d.id, ...d.data() }));
    },
  },
});
